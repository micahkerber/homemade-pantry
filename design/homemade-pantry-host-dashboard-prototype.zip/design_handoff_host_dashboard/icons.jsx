/* ── Icon set (Feather-style stroke icons) ── */
const ICON_PATHS = {
  home: '<path d="M3 9.5 12 3l9 6.5V20a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
  inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.5 5h13l3.5 7v6a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-6Z"/>',
  calendar: '<rect x="3" y="4.5" width="18" height="16" rx="2"/><path d="M3 9h18M8 2.5v4M16 2.5v4"/>',
  users: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5"/><path d="M16 5.2a3.2 3.2 0 0 1 0 6M17.5 14.6c2.2.5 3.5 2.4 3.5 5.4"/>',
  dollar: '<path d="M12 2v20M17 6.5C17 4.6 14.8 3.5 12 3.5S7 4.7 7 7s2.2 3 5 3.5 5 1.4 5 3.6-2.2 3.4-5 3.4-5-1.1-5-3"/>',
  clipboard: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v1"/><path d="M8.5 11.5l2 2 4-4"/>',
  book: '<path d="M4 4.5A2 2 0 0 1 6 3h13v15H6a2 2 0 0 0-2 2Z"/><path d="M4 19.5A2 2 0 0 1 6 18h13v3H6a2 2 0 0 1-2-2Z"/>',
  mail: '<rect x="2.5" y="5" width="19" height="14" rx="2"/><path d="m3 6.5 9 6 9-6"/>',
  star: '<path d="m12 3 2.6 5.6 6 .7-4.5 4.2 1.2 6L12 16.6 6.7 19.5l1.2-6L3.4 9.3l6-.7Z"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v2.5M12 19.5V22M4.2 4.2l1.8 1.8M18 18l1.8 1.8M2 12h2.5M19.5 12H22M4.2 19.8 6 18M18 6l1.8-1.8"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  bell: '<path d="M18 8.5a6 6 0 0 0-12 0c0 6-2.5 7.5-2.5 7.5h17S18 14.5 18 8.5Z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  arrowRight: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  chevronRight: '<path d="m9 6 6 6-6 6"/>',
  chevronLeft: '<path d="m15 6-6 6 6 6"/>',
  chevronDown: '<path d="m6 9 6 6 6-6"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  mapPin: '<path d="M12 21s7-5.5 7-11a7 7 0 1 0-14 0c0 5.5 7 11 7 11Z"/><circle cx="12" cy="10" r="2.5"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',
  phone: '<path d="M5 3h3.5l1.5 5-2.2 1.3a12 12 0 0 0 5.7 5.7L16 13l5 1.5V18a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-3Z"/>',
  trendUp: '<path d="M3 17 9 11l4 4 8-8"/><path d="M17 7h4v4"/>',
  trendDown: '<path d="M3 7l6 6 4-4 8 8"/><path d="M17 17h4v-4"/>',
  seat: '<path d="M5 11V6a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v5M4 11h16v6M6 17v3M18 17v3"/>',
  loaf: '<path d="M4 14a8 8 0 0 1 16 0 1 1 0 0 1-1 1H5a1 1 0 0 1-1-1Z"/><path d="M9 10.5v3.5M12 10v4M15 10.5v3.5"/>',
  jar: '<path d="M7 3h10M8 3v2.5c0 1-2 2-2 4.5v8a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-8c0-2.5-2-3.5-2-4.5V3"/><path d="M6 12h12"/>',
  printer: '<path d="M6 9V3h12v6M6 18H4a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-2"/><rect x="7" y="15" width="10" height="6" rx="1"/>',
  download: '<path d="M12 3v12M7 11l5 5 5-5M5 21h14"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16Z"/><path d="m14 6 4 4"/>',
  message: '<path d="M21 12a8 8 0 0 1-11.5 7.2L3 21l1.8-6.5A8 8 0 1 1 21 12Z"/>',
  send: '<path d="M21 3 10.5 13.5M21 3l-6.5 18-4-8-8-4Z"/>',
  heart: '<path d="M12 20s-7-4.6-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.4-7 10-7 10Z"/>',
  sparkle: '<path d="M12 3v6M12 15v6M3 12h6M15 12h6M6 6l3 3M15 15l3 3M18 6l-3 3M9 15l-3 3"/>',
  filter: '<path d="M3 5h18l-7 8v6l-4-2v-4Z"/>',
  more: '<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>',
  external: '<path d="M14 4h6v6M20 4l-9 9M18 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6"/>',
  butter: '<path d="M4 13h16v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1Z"/><path d="m4 13 4-4h12l-4 4M16 9V6"/>',
  cake: '<path d="M4 21V12a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v9M4 16h16M12 10V6M12 4.5 13 6h-2Z"/>',
};

function Icon({ name, size = 18, style, className }) {
  const p = ICON_PATHS[name] || '';
  return (
    <svg
      width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"
      className={className} style={style}
      dangerouslySetInnerHTML={{ __html: p }}
    />
  );
}

/* The wheat-stalk logo mark (cream on transparent) */
function WheatMark({ size = 26, color = '#FDF9F4' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 90 130" fill="none" aria-hidden="true">
      <path d="M45 124 C44 96 43 70 45 46 C46 28 48 18 48 8" stroke={color} strokeWidth="2.4" strokeLinecap="round" opacity="0.95"/>
      <ellipse cx="45" cy="14" rx="6.5" ry="14" fill={color} opacity="0.95"/>
      <ellipse cx="33" cy="34" rx="6.5" ry="14" fill={color} opacity="0.9" transform="rotate(-22 33 34)"/>
      <ellipse cx="57" cy="34" rx="6.5" ry="14" fill={color} opacity="0.9" transform="rotate(22 57 34)"/>
      <ellipse cx="31" cy="58" rx="6" ry="13" fill={color} opacity="0.8" transform="rotate(-20 31 58)"/>
      <ellipse cx="59" cy="58" rx="6" ry="13" fill={color} opacity="0.8" transform="rotate(20 59 58)"/>
      <ellipse cx="33" cy="82" rx="5.5" ry="12" fill={color} opacity="0.65" transform="rotate(-18 33 82)"/>
      <ellipse cx="57" cy="82" rx="5.5" ry="12" fill={color} opacity="0.65" transform="rotate(18 57 82)"/>
    </svg>
  );
}

/* ── small shared bits ── */
function Avatar({ name, tone = 'teal', size = 36 }) {
  const initial = (name || '?').trim().charAt(0).toUpperCase();
  return (
    <div className={`av av-${tone}`} style={{ width: size, height: size, fontSize: size * 0.42 }}>
      {initial}
    </div>
  );
}

function Badge({ tone = 'teal', children, dot = true }) {
  return (
    <span className={`badge badge-${tone}`}>
      {dot && <span className="dot"></span>}
      {children}
    </span>
  );
}

function Stars({ n }) {
  return <div className="review-stars">{'★'.repeat(n)}{'☆'.repeat(5 - n)}</div>;
}

/* ── date helpers ── */
const DOW = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const DOW_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

function parseDate(str) { const [y, m, d] = str.split('-').map(Number); return new Date(y, m - 1, d); }
function fmtDate(str, opt = {}) {
  const d = parseDate(str);
  const dow = opt.dow ? DOW[d.getDay()] + ', ' : '';
  return `${dow}${MONTHS[d.getMonth()].slice(0,3)} ${d.getDate()}`;
}
function daysFromToday(str) {
  const d = parseDate(str);
  const today = window.PantryData.TODAY;
  return Math.round((d - new Date(today.getFullYear(), today.getMonth(), today.getDate())) / 86400000);
}
function relDay(str) {
  const n = daysFromToday(str);
  if (n === 0) return 'Today';
  if (n === 1) return 'Tomorrow';
  if (n === -1) return 'Yesterday';
  if (n > 0) return `In ${n} days`;
  return `${-n} days ago`;
}
function money(n) { return '$' + n.toLocaleString('en-US'); }

Object.assign(window, { Icon, WheatMark, Avatar, Badge, Stars, ICON_PATHS,
  parseDate, fmtDate, daysFromToday, relDay, money, DOW, DOW_SHORT, MONTHS });
