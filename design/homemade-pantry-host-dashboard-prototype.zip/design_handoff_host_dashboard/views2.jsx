/* ════════ VIEWS — part 2: Guests · Revenue · Prep · Menus · Messages · Reviews · Settings ════════ */

/* ───────────────────────── GUESTS ───────────────────────── */
function GuestsView() {
  const ctx = useDash();
  const q = ctx.query.toLowerCase();
  const guests = window.PantryData.GUESTS
    .filter(g => !q || g.name.toLowerCase().includes(q) || g.email.toLowerCase().includes(q))
    .sort((a, b) => b.evenings - a.evenings);
  const tones = ['teal', 'clay', 'sage', 'gold'];
  const totalGuests = window.PantryData.GUESTS.length;
  const returning = window.PantryData.GUESTS.filter(g => g.evenings > 1).length;

  return (
    <div className="view">
      <div className="section-head">
        <div>
          <div className="eyebrow" style={{ marginBottom: 6 }}>Guests</div>
          <h1 className="serif" style={{ fontSize: '1.5rem' }}>The people at our table</h1>
        </div>
        <div style={{ display: 'flex', gap: 28 }}>
          <div style={{ textAlign: 'right' }}><div className="serif" style={{ fontSize: '1.4rem' }}>{totalGuests}</div><div className="eyebrow-gray">Total guests</div></div>
          <div style={{ textAlign: 'right' }}><div className="serif" style={{ fontSize: '1.4rem' }}>{returning}</div><div className="eyebrow-gray">Returning</div></div>
        </div>
      </div>
      <div className="guest-grid">
        {guests.map((g, i) => (
          <div className="guest-card" key={g.id} onClick={() => ctx.showToast(`Opening ${g.name}'s history`)}>
            <div className="guest-top">
              <Avatar name={g.name} tone={tones[i % 4]} size={46} />
              <div style={{ flex: 1 }}>
                <div className="guest-name">{g.name}</div>
                <div className="guest-since">Guest since {g.since}</div>
              </div>
              <Badge tone={g.evenings > 2 ? 'gold' : 'gray'} dot={false}>
                {g.evenings}× {g.evenings > 2 ? '· regular' : ''}
              </Badge>
            </div>
            <div className="guest-contact">
              <div><Icon name="mail" size={13} /> {g.email}</div>
              <div><Icon name="phone" size={13} /> {g.phone}</div>
            </div>
            {g.note && <div className="guest-note">“{g.note}”</div>}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ───────────────────────── REVENUE ───────────────────────── */
function RevenueView() {
  const ctx = useDash();
  const PD = window.PantryData;
  const data = PD.REVENUE_MONTHLY;
  const max = Math.max(...data.map(d => d.revenue));
  const ytd = data.reduce((s, d) => s + d.revenue, 0);
  const totalEvenings = data.reduce((s, d) => s + d.evenings, 0);
  const avg = Math.round(ytd / totalEvenings);

  const recent = ctx.evenings
    .filter(e => e.status === 'completed' || e.status === 'confirmed')
    .sort((a, b) => parseDate(b.date) - parseDate(a.date)).slice(0, 6);

  const bySource = [
    { label: 'Sourdough & Preserves', tone: 'teal', val: ctx.evenings.filter(e => e.pillar === 'sourdough').reduce((s, e) => s + e.revenue, 0) },
    { label: 'Baking & Pastry', tone: 'clay', val: ctx.evenings.filter(e => e.pillar === 'pastry').reduce((s, e) => s + e.revenue, 0) },
  ];
  const srcTotal = bySource.reduce((s, b) => s + b.val, 0);

  return (
    <div className="view">
      <div className="section-head">
        <div>
          <div className="eyebrow" style={{ marginBottom: 6 }}>Revenue</div>
          <h1 className="serif" style={{ fontSize: '1.5rem' }}>How the season is going</h1>
        </div>
        <button className="btn btn-ghost" onClick={() => ctx.showToast('Exporting revenue report (CSV)')}>
          <Icon name="download" size={15} /> Export
        </button>
      </div>

      <div className="stat-grid" style={{ marginBottom: 'var(--gap)' }}>
        <div className="stat"><div className="stat-top"><div className="stat-ico teal"><Icon name="dollar" /></div><span className="stat-trend up"><Icon name="trendUp" size={12} />+12%</span></div><div className="stat-value">{money(ytd)}</div><div className="stat-label">Revenue · YTD</div><div className="stat-foot">Jan – Jun 2026</div></div>
        <div className="stat"><div className="stat-top"><div className="stat-ico sage"><Icon name="calendar" /></div></div><div className="stat-value">{totalEvenings}</div><div className="stat-label">Evenings hosted</div><div className="stat-foot">Across both pillars</div></div>
        <div className="stat"><div className="stat-top"><div className="stat-ico gold"><Icon name="seat" /></div></div><div className="stat-value">{money(avg)}</div><div className="stat-label">Avg. per evening</div><div className="stat-foot">~{Math.round(avg / PD.SEAT)} seats filled</div></div>
        <div className="stat"><div className="stat-top"><div className="stat-ico clay"><Icon name="trendUp" /></div><span className="stat-trend up"><Icon name="trendUp" size={12} />+8%</span></div><div className="stat-value">{money(PD.SEAT)}</div><div className="stat-label">Seat price</div><div className="stat-foot">Per guest, per evening</div></div>
      </div>

      <div className="grid-2" style={{ marginBottom: 'var(--gap)' }}>
        <div className="card card-pad">
          <div className="section-head" style={{ marginBottom: 6 }}>
            <div className="section-title" style={{ fontSize: '1.05rem' }}>Monthly revenue</div>
            <span className="ital" style={{ fontSize: '.9rem' }}>2026</span>
          </div>
          <div className="chart">
            {data.map(d => (
              <div className="chart-col" key={d.month}>
                <span className="chart-val">{(d.revenue / 1000).toFixed(1)}k</span>
                <div className="chart-bar-wrap">
                  <div className={`chart-bar ${d.partial ? 'partial' : ''}`} style={{ height: `${d.revenue / max * 100}%` }} title={money(d.revenue)}></div>
                </div>
                <span className="chart-label">{d.month}</span>
              </div>
            ))}
          </div>
          <p className="ital" style={{ fontSize: '.86rem', marginTop: 14, textAlign: 'center' }}>
            June is still in progress — striped bar shows bookings so far.
          </p>
        </div>

        <div className="card card-pad">
          <div className="section-title" style={{ fontSize: '1.05rem', marginBottom: 18 }}>By pillar</div>
          {bySource.map(b => (
            <div key={b.label} style={{ marginBottom: 18 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <span style={{ fontSize: '.82rem', fontWeight: 500 }}>{b.label}</span>
                <span className="tbl-amount" style={{ fontSize: '.9rem' }}>{money(b.val)}</span>
              </div>
              <div className="prep-progress"><div style={{ width: `${b.val / srcTotal * 100}%`, background: b.tone === 'teal' ? 'var(--teal)' : 'var(--clay)' }}></div></div>
              <div style={{ fontSize: '.7rem', color: 'var(--gray)', marginTop: 5 }}>{Math.round(b.val / srcTotal * 100)}% of total</div>
            </div>
          ))}
          <div style={{ borderTop: '1px solid var(--linen)', marginTop: 20, paddingTop: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <span className="eyebrow-gray">All-time bookings</span>
            <span className="serif" style={{ fontSize: '1.3rem' }}>{money(srcTotal)}</span>
          </div>
        </div>
      </div>

      <div className="card" style={{ overflow: 'hidden' }}>
        <div className="card-pad" style={{ paddingBottom: 0 }}>
          <div className="section-title" style={{ fontSize: '1.05rem' }}>Recent evenings &amp; payments</div>
        </div>
        <table className="tbl" style={{ marginTop: 12 }}>
          <thead><tr><th>Evening</th><th>Pillar</th><th>Seats paid</th><th>Status</th><th style={{ textAlign: 'right' }}>Revenue</th></tr></thead>
          <tbody>
            {recent.map(ev => {
              const p = pillarOf(ev.pillar);
              const paidStatus = ev.status === 'completed' ? 'Settled' : (ev.paid === ev.seats ? 'Paid in full' : 'Deposits in');
              return (
                <tr key={ev.id} onClick={() => ctx.openEvening(ev.id)}>
                  <td><div style={{ fontWeight: 500 }}>{fmtDate(ev.date, { dow: true })}</div><div style={{ fontSize: '.72rem', color: 'var(--gray)' }}>{ev.location}</div></td>
                  <td><Badge tone={p.accent === 'teal' ? 'teal' : 'clay'}>{p.name}</Badge></td>
                  <td style={{ fontVariantNumeric: 'tabular-nums' }}>{ev.paid} × {money(window.PantryData.SEAT)}</td>
                  <td><Badge tone={ev.status === 'completed' ? 'sage' : 'gray'} dot={false}>{paidStatus}</Badge></td>
                  <td style={{ textAlign: 'right' }} className="tbl-amount">{money(ev.revenue)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ───────────────────────── PREP & INVENTORY ───────────────────────── */
function PrepView() {
  const ctx = useDash();
  const upcoming = ctx.evenings
    .filter(e => e.status === 'confirmed' && daysFromToday(e.date) >= 0)
    .sort((a, b) => parseDate(a.date) - parseDate(b.date));

  const iconFor = (name) => {
    const n = name.toLowerCase();
    if (n.includes('loaf') || n.includes('bread') || n.includes('artisan')) return 'loaf';
    if (n.includes('jam')) return 'jar';
    if (n.includes('butter')) return 'butter';
    if (n.includes('cake')) return 'cake';
    if (n.includes('tart') || n.includes('shell')) return 'sparkle';
    if (n.includes('recipe') || n.includes('card')) return 'printer';
    if (n.includes('starter')) return 'jar';
    if (n.includes('buttercream')) return 'butter';
    return 'clipboard';
  };

  return (
    <div className="view">
      <div className="section-head">
        <div>
          <div className="eyebrow" style={{ marginBottom: 6 }}>Prep &amp; take-home</div>
          <h1 className="serif" style={{ fontSize: '1.5rem' }}>What needs making</h1>
        </div>
        <p className="ital" style={{ fontSize: '1rem', maxWidth: 280, textAlign: 'right' }}>
          Everything guests make, they keep. Check things off as they’re ready.
        </p>
      </div>

      {upcoming.length === 0 && (
        <div className="card"><div className="empty">
          <div className="empty-ico"><Icon name="check" size={26} /></div>
          <div className="empty-title">Nothing to prep</div>
          <div className="empty-sub">No confirmed evenings on the horizon.</div>
        </div></div>
      )}

      <div className="grid-2e">
        {upcoming.map(ev => {
          const p = pillarOf(ev.pillar); const h = hostOf(ev.pillar);
          const ps = prepStats(ev);
          const tone = p.accent === 'teal' ? 'teal' : 'clay';
          return (
            <div className="card" key={ev.id}>
              <div className="card-pad" style={{ paddingBottom: 14, borderBottom: '1px solid var(--linen)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
                  <div className={`pillar-stripe ${tone === 'teal' ? 'stripe-teal' : 'stripe-clay'}`} style={{ height: 40 }}></div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                      <span className="serif" style={{ fontSize: '1.1rem' }}>{fmtDate(ev.date, { dow: true })}</span>
                      <span className="badge badge-gray">{relDay(ev.date)}</span>
                    </div>
                    <div className="lrow-sub">{p.name} · {h.first} · {ev.location}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div className="serif" style={{ fontSize: '1.2rem', color: tone === 'teal' ? 'var(--teal)' : 'var(--clay)' }}>{ps.pct}%</div>
                    <div className="eyebrow-gray">{ps.done}/{ps.total} done</div>
                  </div>
                </div>
                <div className="prep-progress"><div style={{ width: ps.pct + '%', background: tone === 'teal' ? 'var(--teal)' : 'var(--clay)' }}></div></div>
              </div>
              <div className="card-pad" style={{ paddingTop: 6, paddingBottom: 10 }}>
                {ev.prep.map((item, idx) => (
                  <div key={idx} className={`prep-item ${item.done ? 'done' : ''}`} onClick={() => ctx.togglePrep(ev.id, idx)}>
                    <div className="prep-check"><Icon name="check" size={13} /></div>
                    <Icon name={iconFor(item.item)} size={16} style={{ color: item.done ? 'var(--gray-soft)' : (tone === 'teal' ? 'var(--teal)' : 'var(--clay)'), flexShrink: 0 }} />
                    <span className="prep-name">{item.item}</span>
                    <span className="prep-qty">×{item.qty}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ───────────────────────── MENUS / PILLARS ───────────────────────── */
function MenusView() {
  const PD = window.PantryData;
  const pillars = [PD.PILLARS.sourdough, PD.PILLARS.pastry];
  return (
    <div className="view">
      <div className="section-head">
        <div>
          <div className="eyebrow" style={{ marginBottom: 6 }}>Menus</div>
          <h1 className="serif" style={{ fontSize: '1.5rem' }}>Two pillars, one kitchen</h1>
        </div>
      </div>
      <div className="grid-2e">
        {pillars.map(p => {
          const h = PD.HOSTS[p.host];
          const tone = p.accent === 'teal' ? 'teal' : 'clay';
          return (
            <div className="pillar-block" key={p.key}>
              <div className={`pillar-banner ${tone}`}>
                <div className="next-eyebrow" style={{ color: tone === 'teal' ? 'var(--teal-light)' : 'var(--clay-light)' }}>{p.tag}</div>
                <h2 className="serif" style={{ fontSize: '1.6rem', color: '#fff', marginTop: 8 }}>{p.name}</h2>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 16 }}>
                  <Avatar name={h.name} tone={tone === 'teal' ? 'teal' : 'clay'} size={36} />
                  <div>
                    <div style={{ color: '#fff', fontSize: '.85rem', fontWeight: 500 }}>{h.name}</div>
                    <div style={{ color: 'rgba(255,255,255,.7)', fontSize: '.7rem', letterSpacing: '.04em' }}>{h.role}</div>
                  </div>
                </div>
              </div>
              <div className="card-pad">
                <div className="drawer-sec-label">Guests make &amp; take home</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 22 }}>
                  {p.makes.map(m => <span key={m} className={`chip ${tone === 'clay' ? 'chip-clay' : ''}`}>{m}</span>)}
                </div>
                <div className="drawer-sec-label">The evening</div>
                <p className="ital" style={{ fontSize: '1rem', lineHeight: 1.7, marginBottom: 18 }}>
                  {p.key === 'sourdough'
                    ? 'From a live sourdough starter to hand-churned butter and small-batch seasonal jam — every step done by hand, every technique yours to take home. A ~3 hour evening for up to six.'
                    : 'Brittany’s professional pastry training, in your hands. Each gathering focuses on a seasonal technique — laminated doughs, artisan breads, pastry fundamentals. You leave knowing how to do it again.'}
                </p>
                <div style={{ display: 'flex', gap: 22, paddingTop: 16, borderTop: '1px solid var(--linen)' }}>
                  <div><div className="serif" style={{ fontSize: '1.2rem' }}>{money(PD.SEAT)}</div><div className="eyebrow-gray">Per seat</div></div>
                  <div><div className="serif" style={{ fontSize: '1.2rem' }}>6</div><div className="eyebrow-gray">Max guests</div></div>
                  <div><div className="serif" style={{ fontSize: '1.2rem' }}>~3 hrs</div><div className="eyebrow-gray">Duration</div></div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ───────────────────────── MESSAGES ───────────────────────── */
function MessagesView() {
  const ctx = useDash();
  const [activeId, setActiveId] = React.useState(ctx.messages[0]?.id);
  const active = ctx.messages.find(m => m.id === activeId);
  const open = (m) => { setActiveId(m.id); ctx.markMessageRead(m.id); };

  return (
    <div className="view">
      <div className="section-head">
        <div>
          <div className="eyebrow" style={{ marginBottom: 6 }}>Messages</div>
          <h1 className="serif" style={{ fontSize: '1.5rem' }}>Inquiries &amp; notes</h1>
        </div>
        <span className="badge badge-clay" dot={false}>{ctx.messages.filter(m => m.unread).length} unread</span>
      </div>
      <div className="grid-2" style={{ gridTemplateColumns: '0.9fr 1.1fr' }}>
        <div className="card" style={{ padding: 8 }}>
          <div className="msg-list">
            {ctx.messages.map(m => (
              <div key={m.id} className={`msg-row ${m.id === activeId ? 'active' : ''}`} onClick={() => open(m)}>
                <Avatar name={m.name} tone="sage" size={40} />
                <div className="msg-body">
                  <div className="msg-top">
                    <span className={`msg-name ${m.unread ? 'unread' : ''}`}>{m.name}</span>
                    <span className="msg-time">{m.time}</span>
                  </div>
                  <div className="msg-preview">{m.preview}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="card card-pad">
          {active && (
            <div className="msg-detail" key={active.id}>
              <div className="msg-detail-head">
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <Avatar name={active.name} tone="sage" size={44} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: '1rem', fontWeight: 500 }}>{active.name}</div>
                    <div className="lrow-sub">{window.PantryData.gmap[active.guestId]?.email} · {active.time}</div>
                  </div>
                  <button className="btn btn-ghost btn-sm" onClick={() => ctx.showToast('Opening guest profile')}><Icon name="user" size={14} /> Profile</button>
                </div>
              </div>
              <div className="msg-detail-body">“{active.body}”</div>
              <div className="reply-box">
                <textarea className="reply-input" placeholder={`Reply to ${active.name.split(' ')[0]}…`}></textarea>
                <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
                  <button className="btn btn-primary" onClick={() => ctx.showToast('Reply sent')}><Icon name="send" size={15} /> Send reply</button>
                  <button className="btn btn-ghost" onClick={() => ctx.showToast('Saved as draft')}>Save draft</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ───────────────────────── REVIEWS ───────────────────────── */
function ReviewsView() {
  const ctx = useDash();
  const PD = window.PantryData;
  const reviews = PD.REVIEWS;
  const avg = (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1);
  return (
    <div className="view">
      <div className="section-head">
        <div>
          <div className="eyebrow" style={{ marginBottom: 6 }}>Reviews</div>
          <h1 className="serif" style={{ fontSize: '1.5rem' }}>What guests are saying</h1>
        </div>
        <div style={{ display: 'flex', gap: 28, alignItems: 'center' }}>
          <div style={{ textAlign: 'right' }}>
            <div className="serif" style={{ fontSize: '1.6rem' }}>{avg} <span style={{ color: 'var(--clay)', fontSize: '1rem' }}>★</span></div>
            <div className="eyebrow-gray">{reviews.length} reviews</div>
          </div>
        </div>
      </div>
      <div className="review-masonry">
        {reviews.map(r => {
          const p = pillarOf(r.pillar);
          return (
            <div className="review-card" key={r.id}>
              {r.featured && <div style={{ marginBottom: 12 }}><Badge tone="gold" dot={false}>★ Featured on site</Badge></div>}
              <Stars n={r.rating} />
              <p className="review-text">“{r.text}”</p>
              <div className="review-foot">
                <Avatar name={r.name} tone={p.accent === 'teal' ? 'teal' : 'clay'} size={38} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '.82rem', fontWeight: 500 }}>{r.name}</div>
                  <div className="lrow-sub">{p.name} · {r.date}</div>
                </div>
                <button className="top-icon-btn" style={{ width: 34, height: 34 }} onClick={() => ctx.showToast(r.featured ? 'Removed from site' : 'Added to website')} title="Feature on site">
                  <Icon name="heart" size={15} style={{ color: r.featured ? 'var(--clay)' : 'var(--gray-soft)' }} />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ───────────────────────── SETTINGS ───────────────────────── */
function SettingsView() {
  const ctx = useDash();
  const PD = window.PantryData;
  const [toggles, setToggles] = React.useState({ requests: true, reminders: true, reviews: false, digest: true });
  const flip = (k) => { setToggles(t => ({ ...t, [k]: !t[k] })); ctx.showToast('Preference updated'); };

  return (
    <div className="view" style={{ maxWidth: 820 }}>
      <div className="section-head">
        <div>
          <div className="eyebrow" style={{ marginBottom: 6 }}>Settings</div>
          <h1 className="serif" style={{ fontSize: '1.5rem' }}>The pantry, your way</h1>
        </div>
      </div>

      <div className="stack">
        <div className="card card-pad">
          <div className="section-title" style={{ fontSize: '1.05rem', marginBottom: 6 }}>Hosts</div>
          {Object.values(PD.HOSTS).map(h => (
            <div className="set-row" key={h.id}>
              <Avatar name={h.name} tone={h.id === 'jaime' ? 'teal' : 'clay'} size={46} />
              <div className="set-row-text">
                <div className="set-row-title">{h.name}</div>
                <div className="set-row-sub">{h.role} · {h.pillar}</div>
              </div>
              <button className="btn btn-ghost btn-sm" onClick={() => ctx.showToast(`Editing ${h.first}'s profile`)}><Icon name="edit" size={14} /> Edit</button>
            </div>
          ))}
        </div>

        <div className="card card-pad">
          <div className="section-title" style={{ fontSize: '1.05rem', marginBottom: 6 }}>Evening defaults</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginTop: 8 }}>
            <div><label className="field-label">Seat price</label><input className="field-input" defaultValue={money(PD.SEAT)} /></div>
            <div><label className="field-label">Max guests</label><input className="field-input" defaultValue="6" /></div>
            <div><label className="field-label">Default start time</label><input className="field-input" defaultValue="6:00 PM" /></div>
            <div><label className="field-label">Experience length</label><input className="field-input" defaultValue="~3 hours" /></div>
          </div>
          <div style={{ marginTop: 16 }}>
            <button className="btn btn-primary btn-sm" onClick={() => ctx.showToast('Defaults saved')}>Save defaults</button>
          </div>
        </div>

        <div className="card card-pad">
          <div className="section-title" style={{ fontSize: '1.05rem', marginBottom: 6 }}>Notifications</div>
          {[
            { k: 'requests', t: 'New booking requests', s: 'Get notified the moment a guest requests an evening.' },
            { k: 'reminders', t: 'Guest reminders', s: 'Automatically remind guests 2 days before their evening.' },
            { k: 'reviews', t: 'New reviews', s: 'Alert me when a guest leaves a review to approve for the site.' },
            { k: 'digest', t: 'Weekly digest', s: 'A Sunday-evening summary of the week ahead.' },
          ].map(r => (
            <div className="set-row" key={r.k}>
              <div className="set-row-text">
                <div className="set-row-title">{r.t}</div>
                <div className="set-row-sub">{r.s}</div>
              </div>
              <div className={`toggle ${toggles[r.k] ? 'on' : ''}`} onClick={() => flip(r.k)}></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { GuestsView, RevenueView, PrepView, MenusView, MessagesView, ReviewsView, SettingsView });
