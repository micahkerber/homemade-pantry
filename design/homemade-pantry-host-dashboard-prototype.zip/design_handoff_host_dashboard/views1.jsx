/* ════════ VIEWS — part 1: Overview · Bookings · Calendar · Drawer ════════ */

function useDash() { return React.useContext(window.DashCtx); }

/* ── shared helpers over evenings ── */
function pillarOf(key) { return window.PantryData.PILLARS[key]; }
function hostOf(key) { return window.PantryData.HOSTS[pillarOf(key).host]; }
function prepStats(ev) {
  const total = ev.prep.length, done = ev.prep.filter(p => p.done).length;
  return { total, done, pct: total ? Math.round(done / total * 100) : 0 };
}

/* ───────────────────────── OVERVIEW ───────────────────────── */
function OverviewView() {
  const ctx = useDash();
  const { evenings, requests } = ctx;
  const PD = window.PantryData;

  const upcoming = evenings
    .filter(e => e.status !== 'completed' && daysFromToday(e.date) >= 0)
    .sort((a, b) => parseDate(a.date) - parseDate(b.date));
  const next = upcoming[0];
  const monthRev = evenings
    .filter(e => parseDate(e.date).getMonth() === 5 && parseDate(e.date).getFullYear() === 2026)
    .reduce((s, e) => s + e.revenue, 0);
  const seatsThisMonth = evenings.filter(e => parseDate(e.date).getMonth() === 5)
    .reduce((a, e) => ({ filled: a.filled + e.paid, cap: a.cap + e.seats }), { filled: 0, cap: 0 });
  const occ = Math.round(seatsThisMonth.filled / seatsThisMonth.cap * 100);

  const stats = [
    { ico: 'calendar', tone: 'teal', value: upcoming.length, label: 'Upcoming evenings', foot: next ? `Next ${relDay(next.date).toLowerCase()}` : '—', trend: null },
    { ico: 'inbox', tone: 'clay', value: requests.length, label: 'Pending requests', foot: requests.length ? 'Awaiting your reply' : 'All caught up', trend: null },
    { ico: 'dollar', tone: 'sage', value: money(monthRev), label: 'June revenue', foot: '+12% vs. May', trend: 'up' },
    { ico: 'seat', tone: 'gold', value: occ + '%', label: 'Seats filled · June', foot: `${seatsThisMonth.filled} of ${seatsThisMonth.cap} seats`, trend: 'up' },
  ];

  const hr = PD.TODAY.getHours();
  const greet = hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="view">
      <div style={{ marginBottom: 'var(--gap)' }}>
        <div className="eyebrow" style={{ marginBottom: 7 }}>
          {DOW[PD.TODAY.getDay()]}, {MONTHS[PD.TODAY.getMonth()]} {PD.TODAY.getDate()}, {PD.TODAY.getFullYear()}
        </div>
        <h1 className="serif" style={{ fontSize: '1.9rem', lineHeight: 1.1 }}>
          {greet}, Jaime &amp; Brittany.
        </h1>
        <p className="ital" style={{ fontSize: '1.1rem', marginTop: 4 }}>
          Here’s how the pantry is looking this week.
        </p>
      </div>

      <div className="stat-grid" style={{ marginBottom: 'var(--gap)' }}>
        {stats.map((s, i) => (
          <div className="stat" key={i}>
            <div className="stat-top">
              <div className={`stat-ico ${s.tone}`}><Icon name={s.ico} /></div>
              {s.trend && (
                <span className={`stat-trend ${s.trend}`}>
                  <Icon name={s.trend === 'up' ? 'trendUp' : 'trendDown'} size={12} />
                  {s.foot.match(/[+-]\d+%/) ? s.foot.match(/[+-]\d+%/)[0] : ''}
                </span>
              )}
            </div>
            <div className="stat-value">{s.value}</div>
            <div className="stat-label">{s.label}</div>
            <div className="stat-foot">{s.trend ? s.foot.replace(/[+-]\d+% /, '') : s.foot}</div>
          </div>
        ))}
      </div>

      <div className="grid-2" style={{ marginBottom: 'var(--gap)' }}>
        {/* left: next evening + upcoming list */}
        <div className="stack">
          {next && <NextEveningCard ev={next} />}
          <div className="card card-pad">
            <div className="section-head" style={{ marginBottom: 14 }}>
              <div>
                <div className="section-title" style={{ fontSize: '1.05rem' }}>Upcoming evenings</div>
              </div>
              <button className="link-btn" onClick={() => ctx.setNav('calendar')}>
                Calendar <Icon name="arrowRight" size={13} />
              </button>
            </div>
            {upcoming.slice(0, 4).map(ev => {
              const p = pillarOf(ev.pillar); const h = hostOf(ev.pillar);
              return (
                <div className="lrow" key={ev.id} style={{ cursor: 'pointer' }} onClick={() => ctx.openEvening(ev.id)}>
                  <div className={`pillar-stripe ${p.accent === 'teal' ? 'stripe-teal' : 'stripe-clay'}`} style={{ minHeight: 38 }}></div>
                  <div style={{ flex: 1 }}>
                    <div className="lrow-title">{fmtDate(ev.date, { dow: true })} · {ev.time}</div>
                    <div className="lrow-sub">{p.name} · {h.first} · {ev.location}</div>
                  </div>
                  <Badge tone={p.accent === 'teal' ? 'teal' : 'clay'}>{ev.paid}/{ev.seats} seats</Badge>
                  <span className="badge badge-gray" style={{ minWidth: 78, justifyContent: 'center' }}>{relDay(ev.date)}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* right: requests + messages */}
        <div className="stack">
          <div className="card card-pad">
            <div className="section-head" style={{ marginBottom: 14 }}>
              <div className="section-title" style={{ fontSize: '1.05rem' }}>
                Needs your reply
              </div>
              <span className="side-badge" style={{ background: 'var(--clay)' }}>{requests.length}</span>
            </div>
            {requests.length === 0 && <p className="ital">All caught up — no open requests.</p>}
            {requests.slice(0, 3).map(r => {
              const p = pillarOf(r.pillar);
              return (
                <div className="lrow" key={r.id}>
                  <Avatar name={r.name} tone={p.accent === 'teal' ? 'teal' : 'clay'} size={38} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="lrow-title">{r.name}</div>
                    <div className="lrow-sub">{r.party} {r.party > 1 ? 'guests' : 'guest'} · {fmtDate(r.preferredDate)} · {p.name.split(' & ')[0]}</div>
                  </div>
                  <button className="btn btn-primary btn-sm" onClick={() => ctx.approveRequest(r.id)}>
                    <Icon name="check" size={14} />
                  </button>
                  <button className="btn btn-decline btn-sm" onClick={() => ctx.declineRequest(r.id)}>
                    <Icon name="x" size={14} />
                  </button>
                </div>
              );
            })}
            {requests.length > 0 && (
              <button className="link-btn" style={{ marginTop: 14 }} onClick={() => ctx.setNav('bookings')}>
                Review all requests <Icon name="arrowRight" size={13} />
              </button>
            )}
          </div>

          <div className="card card-pad">
            <div className="section-head" style={{ marginBottom: 14 }}>
              <div className="section-title" style={{ fontSize: '1.05rem' }}>Recent messages</div>
              <button className="link-btn" onClick={() => ctx.setNav('messages')}>Inbox <Icon name="arrowRight" size={13} /></button>
            </div>
            {ctx.messages.slice(0, 3).map(m => (
              <div className="lrow" key={m.id} style={{ cursor: 'pointer' }} onClick={() => ctx.setNav('messages')}>
                <Avatar name={m.name} tone="sage" size={34} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="lrow-title" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    {m.name}{m.unread && <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--clay)' }}></span>}
                  </div>
                  <div className="lrow-sub" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 230 }}>{m.preview}</div>
                </div>
                <span className="msg-time">{m.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function NextEveningCard({ ev }) {
  const ctx = useDash();
  const p = pillarOf(ev.pillar); const h = hostOf(ev.pillar);
  const d = parseDate(ev.date);
  return (
    <div className="next-card">
      <div className="next-eyebrow">Your next evening · {relDay(ev.date)}</div>
      <div className="next-date-row">
        <span className="next-day">{MONTHS[d.getMonth()].slice(0,3)} {d.getDate()}</span>
        <span className="next-dow">{DOW[d.getDay()]}, {ev.time}</span>
      </div>
      <div className="next-pillar">{p.name} — led by {h.name}</div>
      <div className="next-meta">
        <div className="next-meta-item">
          <div className="nm-label">Location</div>
          <div className="nm-value"><Icon name="mapPin" size={14} />{ev.location}</div>
        </div>
        <div className="next-meta-item">
          <div className="nm-label">Seats</div>
          <div className="nm-value"><Icon name="seat" size={14} />{ev.paid} of {ev.seats} booked</div>
          <div className="seat-pips">
            {Array.from({ length: ev.seats }).map((_, i) => (
              <span key={i} className={`seat-pip ${i < ev.paid ? 'filled' : ''}`}></span>
            ))}
          </div>
        </div>
        <div className="next-meta-item">
          <div className="nm-label">Prep</div>
          <div className="nm-value"><Icon name="clipboard" size={14} />{prepStats(ev).done}/{prepStats(ev).total} ready</div>
        </div>
      </div>
      <div className="next-actions">
        <button className="btn btn-primary" onClick={() => ctx.openEvening(ev.id)}>
          View evening <Icon name="arrowRight" size={15} />
        </button>
        <button className="btn btn-light" onClick={() => ctx.setNav('prep')}>Prep checklist</button>
      </div>
    </div>
  );
}

/* ───────────────────────── BOOKINGS ───────────────────────── */
function BookingsView() {
  const ctx = useDash();
  const { evenings, requests } = ctx;
  const [filter, setFilter] = React.useState('requests');
  const q = ctx.query.toLowerCase();

  const confirmed = evenings.filter(e => e.status === 'confirmed').sort((a, b) => parseDate(a.date) - parseDate(b.date));
  const completed = evenings.filter(e => e.status === 'completed').sort((a, b) => parseDate(b.date) - parseDate(a.date));

  const filteredReq = requests.filter(r => !q || r.name.toLowerCase().includes(q) || r.pillar.includes(q));
  const matchEv = (list) => list.filter(e => {
    if (!q) return true;
    const names = e.guestIds.map(id => window.PantryData.gmap[id]?.name.toLowerCase() || '').join(' ');
    return pillarOf(e.pillar).name.toLowerCase().includes(q) || names.includes(q) || e.location.toLowerCase().includes(q);
  });

  const tabs = [
    { k: 'requests', label: `Requests · ${requests.length}` },
    { k: 'confirmed', label: `Confirmed · ${confirmed.length}` },
    { k: 'completed', label: `Past · ${completed.length}` },
  ];

  return (
    <div className="view">
      <div className="section-head">
        <div>
          <div className="eyebrow" style={{ marginBottom: 6 }}>Bookings</div>
          <h1 className="serif" style={{ fontSize: '1.5rem' }}>Requests &amp; reservations</h1>
        </div>
        <div className="seg">
          {tabs.map(t => (
            <button key={t.k} className={filter === t.k ? 'on' : ''} onClick={() => setFilter(t.k)}>{t.label}</button>
          ))}
        </div>
      </div>

      {filter === 'requests' && (
        <div className="stack">
          {filteredReq.length === 0 && (
            <div className="card"><div className="empty">
              <div className="empty-ico"><Icon name="check" size={26} /></div>
              <div className="empty-title">No open requests</div>
              <div className="empty-sub">Every guest has heard back from you. Lovely.</div>
            </div></div>
          )}
          {filteredReq.map(r => <RequestCard key={r.id} req={r} />)}
        </div>
      )}

      {filter === 'confirmed' && <BookingsTable list={matchEv(confirmed)} />}
      {filter === 'completed' && <BookingsTable list={matchEv(completed)} past />}
    </div>
  );
}

function RequestCard({ req }) {
  const ctx = useDash();
  const p = pillarOf(req.pillar); const h = hostOf(req.pillar);
  const [resolving, setResolving] = React.useState(false);
  const act = (fn) => { setResolving(true); setTimeout(() => fn(req.id), 280); };
  return (
    <div className={`req-card ${resolving ? 'resolving' : ''}`}>
      <Avatar name={req.name} tone={p.accent === 'teal' ? 'teal' : 'clay'} size={48} />
      <div className="req-main">
        <div className="req-name-row">
          <span className="req-name">{req.name}</span>
          <Badge tone={p.accent === 'teal' ? 'teal' : 'clay'}>{p.name}</Badge>
          <span className="badge badge-gold" style={{ textTransform: 'none', letterSpacing: '.02em' }}>{req.occasion}</span>
        </div>
        <div className="req-meta">
          <span className="req-meta-item"><Icon name="calendar" size={13} /> Prefers <b>{fmtDate(req.preferredDate, { dow: true })}</b></span>
          <span className="req-meta-item"><Icon name="users" size={13} /> <b>{req.party}</b> {req.party > 1 ? 'guests' : 'guest'}</span>
          <span className="req-meta-item"><Icon name="mapPin" size={13} /> {req.location}</span>
          <span className="req-meta-item"><Icon name="user" size={13} /> with {h.first}</span>
        </div>
        <div className="req-msg">“{req.message}”</div>
        <div className="req-meta" style={{ marginTop: 12, marginBottom: 0 }}>
          <span className="req-meta-item"><Icon name="mail" size={13} /> {req.email}</span>
          <span className="req-meta-item"><Icon name="phone" size={13} /> {req.phone}</span>
          <span className="req-meta-item" style={{ color: 'var(--gray-soft)' }}>Submitted {relDay(req.submitted).toLowerCase()}</span>
        </div>
      </div>
      <div className="req-actions">
        <button className="btn btn-primary btn-sm" onClick={() => act(ctx.approveRequest)}>
          <Icon name="check" size={14} /> Approve
        </button>
        <button className="btn btn-decline btn-sm" onClick={() => act(ctx.declineRequest)}>
          <Icon name="x" size={14} /> Decline
        </button>
      </div>
    </div>
  );
}

function BookingsTable({ list, past }) {
  const ctx = useDash();
  if (!list.length) return (
    <div className="card"><div className="empty">
      <div className="empty-ico"><Icon name="calendar" size={26} /></div>
      <div className="empty-title">Nothing here yet</div>
      <div className="empty-sub">Try a different filter or search.</div>
    </div></div>
  );
  return (
    <div className="card" style={{ overflow: 'hidden' }}>
      <table className="tbl">
        <thead>
          <tr>
            <th>Evening</th><th>Pillar</th><th>Host</th><th>Location</th><th>Seats</th><th style={{ textAlign: 'right' }}>Revenue</th>
          </tr>
        </thead>
        <tbody>
          {list.map(ev => {
            const p = pillarOf(ev.pillar); const h = hostOf(ev.pillar);
            return (
              <tr key={ev.id} onClick={() => ctx.openEvening(ev.id)}>
                <td>
                  <div className="cell-name">
                    <div className={`pillar-stripe ${p.accent === 'teal' ? 'stripe-teal' : 'stripe-clay'}`} style={{ height: 30 }}></div>
                    <div>
                      <div style={{ fontWeight: 500 }}>{fmtDate(ev.date, { dow: true })}</div>
                      <div style={{ fontSize: '.72rem', color: 'var(--gray)' }}>{ev.time} · {past ? relDay(ev.date) : relDay(ev.date)}</div>
                    </div>
                  </div>
                </td>
                <td><Badge tone={p.accent === 'teal' ? 'teal' : 'clay'}>{p.name}</Badge></td>
                <td>{h.first}</td>
                <td style={{ color: 'var(--gray)' }}>{ev.location}</td>
                <td><span style={{ fontVariantNumeric: 'tabular-nums' }}>{ev.paid}/{ev.seats}</span></td>
                <td style={{ textAlign: 'right' }} className="tbl-amount">{money(ev.revenue)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/* ───────────────────────── CALENDAR ───────────────────────── */
function CalendarView() {
  const ctx = useDash();
  const PD = window.PantryData;
  const [month, setMonth] = React.useState(5); // June 2026
  const year = 2026;

  const first = new Date(year, month, 1);
  const startPad = first.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < startPad; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);

  const evByDay = {};
  ctx.evenings.forEach(e => {
    const d = parseDate(e.date);
    if (d.getMonth() === month && d.getFullYear() === year) (evByDay[d.getDate()] = evByDay[d.getDate()] || []).push(e);
  });

  const monthEvenings = ctx.evenings.filter(e => parseDate(e.date).getMonth() === month && parseDate(e.date).getFullYear() === year);
  const monthRev = monthEvenings.reduce((s, e) => s + e.revenue, 0);
  const isToday = (d) => month === PD.TODAY.getMonth() && year === PD.TODAY.getFullYear() && d === PD.TODAY.getDate();

  return (
    <div className="view">
      <div className="section-head">
        <div>
          <div className="eyebrow" style={{ marginBottom: 6 }}>Calendar</div>
          <h1 className="serif" style={{ fontSize: '1.5rem' }}>Evenings at a glance</h1>
        </div>
        <div style={{ display: 'flex', gap: 18, alignItems: 'center' }}>
          <div style={{ textAlign: 'right' }}>
            <div className="eyebrow-gray">{monthEvenings.length} evenings · {MONTHS[month]}</div>
            <div className="serif" style={{ fontSize: '1.15rem', marginTop: 2 }}>{money(monthRev)}</div>
          </div>
        </div>
      </div>

      <div className="cal-wrap">
        <div className="cal-head">
          <div className="cal-month">{MONTHS[month]} {year}</div>
          <div className="cal-nav">
            <button onClick={() => setMonth(m => Math.max(0, m - 1))} disabled={month === 0}><Icon name="chevronLeft" size={16} /></button>
            <button onClick={() => setMonth(5)} title="Back to June" style={{ width: 'auto', padding: '0 14px', fontSize: '.72rem', letterSpacing: '.06em', textTransform: 'uppercase', color: 'var(--accent)' }}>Today</button>
            <button onClick={() => setMonth(m => Math.min(11, m + 1))} disabled={month === 11}><Icon name="chevronRight" size={16} /></button>
          </div>
        </div>
        <div className="cal-dow">{DOW_SHORT.map(d => <div key={d}>{d}</div>)}</div>
        <div className="cal-grid">
          {cells.map((d, i) => (
            <div key={i} className={`cal-cell ${d === null ? 'muted' : ''} ${d && isToday(d) ? 'today' : ''}`}>
              {d !== null && <div className="cal-daynum">{d}</div>}
              {d !== null && (evByDay[d] || []).map(ev => {
                const p = pillarOf(ev.pillar);
                return (
                  <div key={ev.id} className={`cal-event ${p.accent === 'teal' ? 'teal' : 'clay'}`} onClick={() => ctx.openEvening(ev.id)}>
                    <div className="ce-time">{ev.time}</div>
                    <div className="ce-name">{p.name.split(' & ')[0]} · {ev.paid}/{ev.seats}</div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', gap: 22, marginTop: 18, alignItems: 'center' }}>
        <span className="req-meta-item" style={{ fontSize: '.74rem' }}><span className="dot" style={{ width: 10, height: 10, borderRadius: 3, background: 'var(--teal)', display: 'inline-block' }}></span> Sourdough &amp; Preserves · Jaime</span>
        <span className="req-meta-item" style={{ fontSize: '.74rem' }}><span className="dot" style={{ width: 10, height: 10, borderRadius: 3, background: 'var(--clay)', display: 'inline-block' }}></span> Baking &amp; Pastry · Brittany</span>
      </div>
    </div>
  );
}

/* ───────────────────────── EVENING DRAWER ───────────────────────── */
function EveningDrawer() {
  const ctx = useDash();
  const ev = ctx.evenings.find(e => e.id === ctx.openEveningId);
  React.useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') ctx.closeDrawer(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  if (!ev) return null;
  const p = pillarOf(ev.pillar); const h = hostOf(ev.pillar);
  const d = parseDate(ev.date);
  const ps = prepStats(ev);
  const guests = ev.guestIds.map(id => window.PantryData.gmap[id]).filter(Boolean);
  const tone = p.accent === 'teal' ? 'teal' : 'clay';

  return (
    <React.Fragment>
      <div className="drawer-scrim" onClick={ctx.closeDrawer}></div>
      <div className="drawer">
        <div className={`drawer-head ${tone}`}>
          <button className="drawer-close" onClick={ctx.closeDrawer}><Icon name="x" size={17} /></button>
          <div className="next-eyebrow" style={{ opacity: .85 }}>{ev.status === 'completed' ? 'Past evening' : relDay(ev.date)}</div>
          <div className="next-date-row" style={{ marginTop: 8 }}>
            <span className="next-day">{MONTHS[d.getMonth()].slice(0,3)} {d.getDate()}</span>
            <span className="next-dow">{DOW[d.getDay()]}, {ev.time}</span>
          </div>
          <div className="next-pillar" style={{ marginBottom: 0 }}>{p.name} — {h.name}</div>
          <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
            <span className="badge" style={{ background: 'rgba(255,255,255,.14)', color: '#fff' }}><Icon name="mapPin" size={12} /> {ev.location}</span>
            <span className="badge" style={{ background: 'rgba(255,255,255,.14)', color: '#fff' }}><Icon name="seat" size={12} /> {ev.paid}/{ev.seats} seats</span>
            <span className="badge" style={{ background: 'rgba(255,255,255,.14)', color: '#fff' }}>{money(ev.revenue)}</span>
          </div>
        </div>

        <div className="drawer-body">
          <div>
            <div className="drawer-sec-label">Guest list · {guests.length}</div>
            <div className="card card-pad" style={{ padding: 0 }}>
              {guests.map((g, i) => (
                <div key={g.id} className="lrow" style={{ padding: '13px 18px' }}>
                  <Avatar name={g.name} tone={['teal','clay','sage','gold'][i % 4]} size={36} />
                  <div style={{ flex: 1 }}>
                    <div className="lrow-title">{g.name}</div>
                    <div className="lrow-sub">{g.email}</div>
                  </div>
                  {g.note && <span title={g.note}><Icon name="sparkle" size={15} style={{ color: 'var(--gold)' }} /></span>}
                </div>
              ))}
              {ev.paid < ev.seats && (
                <div className="lrow" style={{ padding: '13px 18px', color: 'var(--gray-soft)' }}>
                  <div className="av" style={{ width: 36, height: 36, background: 'var(--linen)', color: 'var(--gray-soft)', fontStyle: 'normal' }}>+</div>
                  <div className="ital">{ev.seats - ev.paid} {ev.seats - ev.paid > 1 ? 'seats' : 'seat'} still open</div>
                </div>
              )}
            </div>
          </div>

          <div>
            <div className="drawer-sec-label" style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Prep & take-home · {ps.done}/{ps.total}</span>
              <span style={{ color: tone === 'teal' ? 'var(--teal)' : 'var(--clay)' }}>{ps.pct}%</span>
            </div>
            <div className="prep-progress" style={{ marginBottom: 10 }}><div style={{ width: ps.pct + '%' }}></div></div>
            <div className="card card-pad" style={{ paddingTop: 6, paddingBottom: 6 }}>
              {ev.prep.map((item, idx) => (
                <div key={idx} className={`prep-item ${item.done ? 'done' : ''}`} onClick={() => ctx.togglePrep(ev.id, idx)}>
                  <div className="prep-check"><Icon name="check" size={13} /></div>
                  <span className="prep-name">{item.item}</span>
                  <span className="prep-qty">×{item.qty}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="drawer-sec-label">Logistics</div>
            <div className="card card-pad">
              <div className="lrow" style={{ padding: '9px 0' }}>
                <Icon name="mapPin" size={16} style={{ color: 'var(--gray-soft)' }} />
                <div style={{ flex: 1 }}><div className="lrow-sub" style={{ marginTop: 0 }}>Location</div><div className="lrow-title">{ev.location} · {ev.address}</div></div>
              </div>
              <div className="lrow" style={{ padding: '9px 0' }}>
                <Icon name="clock" size={16} style={{ color: 'var(--gray-soft)' }} />
                <div style={{ flex: 1 }}><div className="lrow-sub" style={{ marginTop: 0 }}>Arrival</div><div className="lrow-title">{ev.time} · ~3 hour experience</div></div>
              </div>
              <div className="lrow" style={{ padding: '9px 0' }}>
                <Icon name="user" size={16} style={{ color: 'var(--gray-soft)' }} />
                <div style={{ flex: 1 }}><div className="lrow-sub" style={{ marginTop: 0 }}>Host</div><div className="lrow-title">{h.name} · {h.role}</div></div>
              </div>
            </div>
          </div>

          {ev.status !== 'completed' && (
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => { ctx.showToast('Reminder sent to all guests'); }}>
                <Icon name="send" size={15} /> Message guests
              </button>
              <button className="btn btn-ghost" onClick={() => ctx.showToast('Opening printable run sheet')}>
                <Icon name="printer" size={15} /> Run sheet
              </button>
            </div>
          )}
        </div>
      </div>
    </React.Fragment>
  );
}

Object.assign(window, { OverviewView, BookingsView, CalendarView, EveningDrawer, useDash, pillarOf, hostOf, prepStats });
