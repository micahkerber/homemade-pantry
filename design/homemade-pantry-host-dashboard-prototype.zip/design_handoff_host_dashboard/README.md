# Handoff: The Homemade Pantry — Host Dashboard

## Overview
A back-of-house admin dashboard for **The Homemade Pantry** (thehomemadepantryco.com), an intimate in-home culinary experience business in Brookshire, TX run by two hosts: **Jaime Kerber** (Founder — "Sourdough & Preserves" evenings) and **Brittany Trevett** (Executive Baker — "Baking & Pastry" evenings). Evenings host up to 6 guests at $145/seat, ~3 hours, at the hosts' home or the guest's.

The dashboard lets the hosts: see upcoming evenings at a glance, approve/decline booking requests, manage a calendar, view guest profiles, track revenue, check off prep/take-home item checklists, review their two menu pillars, answer guest messages, and curate reviews.

## About the Design Files
The files in this bundle are **design references created in HTML** — a working prototype showing the intended look and behavior, **not production code to ship directly**. The task is to **recreate this design in the target codebase's environment** using its established patterns and libraries. If no app environment exists yet, choose an appropriate stack (e.g. Next.js/React + a small backend with a database) and implement the design there, wiring each view to real backend data as described below.

The prototype is plain React 18 (via Babel-in-browser, no build step) + one CSS file. The component decomposition (`app.jsx` shell, `views1.jsx`/`views2.jsx` screens, `icons.jsx` shared primitives) maps cleanly to a real React codebase. `tweaks-panel.jsx` is a design-review tool only — **do not port it**.

## Fidelity
**High-fidelity.** Colors, typography, spacing, copy, and interactions are final and brand-derived (they extend the existing marketing site's design system). Recreate the UI pixel-faithfully. The **data is mock** (`data.js`) — replace it entirely with a real backend.

## Architecture of the prototype
- `Homemade Pantry Dashboard.html` — shell; loads fonts, styles, React, then scripts in order
- `styles.css` — the entire design system (tokens as CSS custom properties + all component classes)
- `data.js` — mock data: `window.PantryData = { HOSTS, PILLARS, SEAT, GUESTS, EVENINGS, REQUESTS, MESSAGES, REVIEWS, REVENUE_MONTHLY, TODAY }`. **This file defines the data shapes the backend should serve.** Note: the prototype pins `TODAY = June 11, 2026` so relative dates render; production should use the real clock.
- `icons.jsx` — `Icon` (24×24 stroke icon set, 1.7px stroke), `WheatMark` logo, `Avatar`, `Badge`, `Stars`, date/money helpers
- `views1.jsx` — Overview, Bookings & Requests, Calendar, Evening detail drawer
- `views2.jsx` — Guests, Revenue, Prep & Take-home, Menus, Messages, Reviews, Settings
- `app.jsx` — sidebar/topbar shell, all shared state, context (`DashCtx`), action handlers

## Screens / Views

### 1. Shell (all screens)
- **Layout**: CSS grid `252px 1fr`, full viewport height. Left sidebar + main column (72px topbar + scrollable content area, content max-width 1240px centered, padding `30px 34px 56px`).
- **Sidebar** (dark gradient `#20302E → #1A2826`): logo block (42px rounded square, teal `#2C6E6A`, wheat-stalk mark) + wordmark "The Homemade Pantry" / "MADE SLOWLY · SHARED WARMLY"; three nav groups — *Kitchen* (Overview, Bookings & Requests, Calendar, Guests), *Business* (Revenue, Prep & Take-home, Menus), *Guests & Word of Mouth* (Messages, Reviews); footer with both hosts' avatars (teal "J", clay "B"), "Jaime & Brittany · Brookshire, TX", and a gear button → Settings.
  - Nav item: 10px/12px padding, 8px radius, `.82rem` Jost; active = translucent teal fill `rgba(168,212,209,.12)`, cream text, 3px accent bar on the left edge. Badge pills (clay `#B87050`, white text) show pending-request count and unread-message count, live.
- **Topbar**: page eyebrow (teal, uppercase, letterspaced) + Playfair page title; right side: contextual search box (only on Bookings and Guests), bell icon button with clay unread dot (→ Messages), primary CTA "＋ New evening" (teal, uppercase Jost).

### 2. Overview
- Greeting block: teal eyebrow with full date, Playfair `1.9rem` "Good evening, Jaime & Brittany.", italic Cormorant subtitle "Here's how the pantry is looking this week."
- **4 stat cards** (grid, equal): icon tile (38px, tinted bg) + Playfair `2.1rem` value + uppercase label + italic footnote. Stats: Upcoming evenings; Pending requests; June revenue (with green ↑ trend chip); Seats filled % for the month.
- **Two-column row (1.55fr / 1fr)**:
  - Left: **Next evening hero card** — dark teal gradient (`#243A38 → #18302D`), radial glow; eyebrow "YOUR NEXT EVENING · IN N DAYS"; Playfair date + italic weekday/time; pillar + host line; three meta columns (Location, Seats with 6 pip indicators, Prep n/m ready); buttons "View evening" (teal solid → opens drawer) and "Prep checklist" (translucent light). Below it: **Upcoming evenings** card — rows with 4px pillar color stripe, date/time title, pillar·host·location subtitle, seats badge, relative-day chip; row click opens the evening drawer.
  - Right: **Needs your reply** card — request rows with avatar, name, party/date/pillar subtitle, inline ✓ approve and ✕ decline buttons; link "Review all requests →". **Recent messages** card — avatar rows with unread dot, preview, time; click → Messages.

### 3. Bookings & Requests
- Header + segmented control: `Requests · n` / `Confirmed · n` / `Past · n` (white pill on warm bg, active tab teal text + shadow). Topbar search filters all tabs.
- **Requests tab**: stacked request cards — 48px avatar; name + pillar badge + gold occasion chip ("Anniversary", "Birthday"…); meta row (icons: prefers date, party size, location, host); guest's message as italic Cormorant blockquote with 2px clay-light left border on warm-white; contact row (email, phone, submitted-when). Right column: **Approve** (teal solid) / **Decline** (white w/ gray border; hover turns soft red). On action the card animates out (`opacity 0, translateX(24px)`, ~280ms) then resolves.
- **Confirmed/Past tabs**: table — Evening (stripe + weekday date + time/relative), Pillar badge, Host, Location, Seats `n/6`, Revenue (Playfair, right-aligned). Rows hover warm-white, click opens drawer. Empty states: 56px teal-pale rounded icon tile + Playfair title + italic sub.

### 4. Calendar
- Header right shows evening count + Playfair monthly revenue total.
- Month grid card: Playfair month title, ‹ / TODAY / › nav (Today jumps to current month); DOW header row; 7-col grid, cells min-height 104px, out-of-month cells warm-white. Today's daynum is a 24px teal circle. Events are small blocks (radius 6, 3px left border): teal-pale for Sourdough, clay-pale for Baking; bold time line + "Pillar · seats" line; click opens drawer.
- Legend under the card: colored squares + "Sourdough & Preserves · Jaime" / "Baking & Pastry · Brittany".

### 5. Evening detail drawer (overlay, from any screen)
- Right-side drawer, 480px, slides in 320ms `cubic-bezier(.22,.61,.36,1)`; scrim `rgba(42,37,32,.42)` + blur; Esc or scrim-click closes.
- Header: gradient (dark teal for Sourdough; dark clay `#5a3826 → #3a2418` for Pastry); relative-day eyebrow, Playfair date + weekday/time, pillar — host line; translucent chips: location, seats, revenue.
- Body: **Guest list** (avatar rows, email; gold sparkle icon = host note, shown via tooltip; trailing "+n seats still open" row when not full) · **Prep & take-home** (progress % + sage progress bar; checklist rows: 22px rounded checkbox → sage fill when done, label gets strikethrough; quantity `×n` right-aligned; rows toggle on click) · **Logistics** (location/address, arrival time + "~3 hour experience", host + role) · footer actions "Message guests" (teal) and "Run sheet" (ghost), hidden for past evenings.

### 6. Guests
- Header stats: total guests, returning count. Search in topbar.
- 3-col card grid: 46px avatar (rotating teal/clay/sage/gold), name, "Guest since {Mon YYYY}", visit-count badge (gold "n× · regular" when >2 visits); divider; email + phone rows with icons; italic host note in quotes. Sorted by visit count desc.

### 7. Revenue
- 4 stat cards: YTD revenue (+trend), Evenings hosted, Avg per evening, Seat price.
- **Monthly revenue bar chart** (Jan–Jun): teal gradient bars, Playfair value labels above (e.g. "5.1k"), current month is a striped teal-pale bar (in progress) with explanatory italic caption.
- **By pillar** card: label + amount rows with proportional progress bars (teal vs clay) + "% of total"; all-time total at bottom.
- **Recent evenings & payments** table: date/location, pillar badge, "n × $145", status badge (sage "Settled" / "Paid in full", gray "Deposits in"), revenue. "Export" ghost button top-right.

### 8. Prep & Take-home
- 2-col grid of per-evening cards (confirmed, future only): header with pillar stripe, Playfair date + relative chip, pillar·host·location, big % + n/m done, full-width progress bar (pillar-colored); body is the same toggleable checklist as the drawer, each item also gets a category icon (loaf, jar, butter, cake, printer…). State is shared with the drawer (same source of truth).

### 9. Menus
- 2 pillar cards: banner (teal gradient / clay gradient) with "PILLAR ONE/TWO" eyebrow, Playfair pillar name, host avatar + name + role; body: "Guests make & take home" chips (teal-pale / clay-pale), italic description paragraph, footer stats row ($145 per seat · 6 max guests · ~3 hrs).

### 10. Messages
- Two panes (0.9fr/1.1fr). Left: conversation list — avatar, name (+ clay unread dot), time, single-line preview; active row teal-pale. Click marks read (updates sidebar badge + bell dot). Right: detail — header (avatar, name, email, "Profile" ghost button), the message as large italic Cormorant quote, reply textarea (warm-white, teal focus border) + "Send reply" / "Save draft".

### 11. Reviews
- Header: Playfair average ("4.8 ★") + review count. 3-column CSS masonry (`columns: 3`).
- Review cards: optional gold "★ Featured on site" badge, clay stars, italic Cormorant quote, divider, avatar + name + pillar·date, heart icon button (clay when featured) to toggle "feature on website".

### 12. Settings
- Max-width 820px stack: **Hosts** (avatar, name, role/pillar, Edit button) · **Evening defaults** (2-col inputs: seat price, max guests, default start time, experience length + Save) · **Notifications** (4 toggle rows: new requests, guest reminders, new reviews, weekly digest; 46×26px pill toggles, teal when on).

## Interactions & Behavior
- **Navigation**: sidebar buttons switch views (state-based in prototype; use routes in production: `/`, `/bookings`, `/calendar`, `/guests`, `/revenue`, `/prep`, `/menus`, `/messages`, `/reviews`, `/settings`). Content scrolls to top on switch; view enters with a subtle 9px rise animation (450ms). **Never gate content visibility on animations** (no `opacity:0` resting states).
- **Approve request**: removes request, decrements sidebar badge, adds the guest + party size to the matching evening (same date + pillar) capped at capacity, increases that evening's `paid` and `revenue` (+$145/seat), shows toast "Approved — {name} added to {date}".
- **Decline request**: removes request, toast "Declined {name}'s request". Both animate the card out first (~280ms).
- **Prep toggle**: optimistic check/uncheck; updates progress bars and counts everywhere (drawer, prep page, overview hero card).
- **Drawer**: opens from overview rows, both tables, calendar events, hero card; Esc/scrim closes.
- **Search** (topbar, Bookings + Guests only): live substring filter on names/emails/pillars/locations.
- **Toast**: bottom-center dark charcoal pill, check icon, 2.6s auto-dismiss, used for all confirmations.
- Buttons/cards: cards lift on hover (`translateY(-2px)` + larger shadow); primary buttons brighten + lift; table rows tint warm-white.

## State Management
Prototype keeps everything in one React context (`DashCtx` in `app.jsx`):
- `nav` (active view), `query` (search), `openEveningId` (drawer), `toast`
- `evenings[]`, `requests[]`, `messages[]` — mutated by `togglePrep(eveningId, idx)`, `approveRequest(id)`, `declineRequest(id)`, `markMessageRead(id)`
In production these become API-backed resources. Suggested backend entities: **Host, Pillar (menu), Evening (date, time, pillar, location, capacity, status), Booking/Request (guest, party, occasion, message, status), Guest (contact, notes, visit history), PrepItem (evening, label, qty, done), Message (thread), Review (rating, text, featured), Payment (seat × $145)**. Derived stats (monthly revenue, occupancy, averages) should be computed server-side.

## Design Tokens
Colors (from the marketing site, reused exactly):
- `--cream #FAF6EF` (app bg) · `--warm-white #FDF9F4` · `--linen #EDE5D8` (borders) · `--linen-deep #E2D8C7`
- `--teal #2C6E6A` (primary accent) · `--teal-mid #3D8C87` · `--teal-light #A8D4D1` · `--teal-pale #E4F4F3` · `--teal-deep #1E4B48`
- `--clay #B87050` (secondary/pastry/badges) · `--clay-light #E8C4A8` · `--clay-pale #F4E6DA`
- `--charcoal/--ink #2A2520` (text) · `--gray #8A847C` · `--gray-soft #ACA69D`
- `--sage #7A9E7E` (success/progress) · `--gold #C99A4B` (highlights/featured)
- Sidebar: `#20302E → #1A2826` gradient, borders `rgba(168,212,209,.10)`

Typography (Google Fonts):
- **Playfair Display** (serif) — page titles, stat values, dates, amounts; weight 500
- **Cormorant Garamond italic** — editorial subtitles, quotes, notes (~.9–1.1rem)
- **Jost** — all UI text; uppercase letterspaced labels (`.54–.6rem`, tracking .18–.28em); body `.74–.92rem`
- Base 15px.

Spacing & shape: card padding 26px, grid gap 22px, card radius 8px, small radius 5px, chips/badges 20px pill. Shadows: `0 1px 2px rgba(42,37,32,.05)` (resting), `0 4px 24px rgba(42,37,32,.07)` (hover), `0 24px 64px rgba(42,37,32,.18)` (drawer).
Density variants exist in CSS via `[data-density="compact|comfy"]` (pad 18/32px, gap 14/28px) and a light sidebar via `[data-side="light"]` — keep if you want user preferences, otherwise ship the defaults (dark sidebar, regular density, teal accent).

## Assets
- **Wheat-stalk logo mark**: drawn inline as SVG in `icons.jsx` (`WheatMark`), derived from the marketing site's logo. Replace with the brand's real logo asset if available.
- **Icons**: inline 24×24 stroke SVG set in `icons.jsx` (1.7px stroke, round caps) — map to Feather/Lucide equivalents in production.
- No raster images are used. Real guest/host photos could replace initial-letter avatars.

## Files
- `Homemade Pantry Dashboard.html` — entry shell (open in a browser to run the prototype)
- `styles.css` — full design system + all component styles
- `data.js` — mock data **and the canonical data shapes**
- `icons.jsx` — icons, logo, avatar/badge primitives, date & money helpers
- `views1.jsx` — Overview, Bookings, Calendar, Evening drawer
- `views2.jsx` — Guests, Revenue, Prep, Menus, Messages, Reviews, Settings
- `app.jsx` — shell, navigation, context, state + action handlers
- `tweaks-panel.jsx` — design-review tweak panel (prototype tooling; **do not port**)
