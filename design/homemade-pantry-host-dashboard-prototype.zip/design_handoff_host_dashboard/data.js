/* ─────────────────────────────────────────────────────────────
   The Homemade Pantry — Host Dashboard mock data
   Plain JS, attached to window.PantryData
   Reference "today": June 11, 2026
   ───────────────────────────────────────────────────────────── */
(function () {
  const HOSTS = {
    jaime: {
      id: "jaime",
      name: "Jaime Kerber",
      first: "Jaime",
      role: "Founder",
      pillar: "Sourdough & Preserves",
      initials: "J",
    },
    brittany: {
      id: "brittany",
      name: "Brittany Trevett",
      first: "Brittany",
      role: "Executive Baker",
      pillar: "Baking & Pastry",
      initials: "B",
    },
  };

  const PILLARS = {
    sourdough: {
      key: "sourdough",
      name: "Sourdough & Preserves",
      host: "jaime",
      tag: "Pillar One",
      accent: "teal",
      makes: [
        "Mini sourdough loaf",
        "Dried starter",
        "Flavored butter",
        "Seasonal jam",
        "Recipe card",
      ],
    },
    pastry: {
      key: "pastry",
      name: "Baking & Pastry",
      host: "brittany",
      tag: "Pillar Two",
      accent: "clay",
      makes: [
        "Mini tart trio",
        "Designer mini cakes",
        "Buttercream",
        "Recipes to keep",
      ],
    },
  };

  const SEAT = 145; // price per seat, USD

  // Guests directory
  const GUESTS = [
    { id: "g1",  name: "Maren Holloway",   email: "maren.holloway@gmail.com",   phone: "(713) 555-0142", evenings: 3, since: "Feb 2026", note: "Gluten-curious — keep an eye on flour dust. Loves the jam course." },
    { id: "g2",  name: "Priya Nadkarni",   email: "priya.nadk@outlook.com",     phone: "(281) 555-0199", evenings: 2, since: "Mar 2026", note: "Booked her sister's birthday last spring." },
    { id: "g3",  name: "Dawson Reed",      email: "dawson.reed@gmail.com",      phone: "(832) 555-0177", evenings: 1, since: "May 2026", note: "First-timer. Came in through Instagram." },
    { id: "g4",  name: "Elena Sorensen",   email: "elena.sorensen@me.com",      phone: "(713) 555-0124", evenings: 4, since: "Jan 2026", note: "Regular. Prefers the Saturday evenings." },
    { id: "g5",  name: "Tomás Iglesias",   email: "tomas.igle@gmail.com",       phone: "(346) 555-0188", evenings: 2, since: "Mar 2026", note: "Nut allergy — note for the pastry pillar." },
    { id: "g6",  name: "Hannah Whitfield", email: "hannah.whit@gmail.com",      phone: "(281) 555-0166", evenings: 1, since: "Apr 2026", note: "" },
    { id: "g7",  name: "Cole Berenson",    email: "cole.b@protonmail.com",      phone: "(713) 555-0133", evenings: 1, since: "May 2026", note: "Anniversary booking with partner." },
    { id: "g8",  name: "Saanvi Rao",       email: "saanvi.rao@gmail.com",       phone: "(832) 555-0155", evenings: 3, since: "Feb 2026", note: "Brings friends every time — best referrer." },
    { id: "g9",  name: "Margaret Fenn",    email: "peggy.fenn@gmail.com",       phone: "(979) 555-0110", evenings: 2, since: "Mar 2026", note: "Local to Brookshire. Walks over." },
    { id: "g10", name: "Devin Park",       email: "devin.park@gmail.com",       phone: "(713) 555-0121", evenings: 1, since: "May 2026", note: "" },
    { id: "g11", name: "Lucia Marchetti",  email: "lucia.m@gmail.com",          phone: "(346) 555-0190", evenings: 2, since: "Apr 2026", note: "Vegetarian. Loved the herb butter." },
    { id: "g12", name: "Reuben Castile",   email: "reuben.c@gmail.com",         phone: "(281) 555-0102", evenings: 1, since: "Jun 2026", note: "" },
    { id: "g13", name: "Ana Belmonte",     email: "ana.belmonte@gmail.com",     phone: "(713) 555-0148", evenings: 2, since: "Feb 2026", note: "Photographer — happy to share photos." },
    { id: "g14", name: "Theo Vanderwall",  email: "theo.v@gmail.com",           phone: "(832) 555-0173", evenings: 1, since: "May 2026", note: "" },
  ];
  const gmap = Object.fromEntries(GUESTS.map((g) => [g.id, g]));

  // Confirmed / completed evenings.  Dates around "today" = 2026-06-11
  const EVENINGS = [
    {
      id: "e1", date: "2026-05-24", time: "6:00 PM", pillar: "sourdough",
      location: "Our Home", address: "Brookshire, TX", status: "completed",
      seats: 6, guestIds: ["g1","g4","g8","g9","g13","g2"],
      paid: 6, revenue: 6 * SEAT,
      prep: [
        { item: "Mini sourdough loaves", qty: 6, done: true },
        { item: "Dried starter packets", qty: 6, done: true },
        { item: "Flavored butter", qty: 6, done: true },
        { item: "Seasonal jam jars", qty: 6, done: true },
        { item: "Recipe cards printed", qty: 6, done: true },
      ],
    },
    {
      id: "e2", date: "2026-06-07", time: "6:00 PM", pillar: "pastry",
      location: "Our Home", address: "Brookshire, TX", status: "completed",
      seats: 6, guestIds: ["g4","g11","g5","g6","g10","g14"],
      paid: 6, revenue: 6 * SEAT,
      prep: [
        { item: "Mini tart shells", qty: 18, done: true },
        { item: "Mini cake bases", qty: 12, done: true },
        { item: "Buttercream batches", qty: 2, done: true },
        { item: "Recipe cards printed", qty: 6, done: true },
      ],
    },
    {
      id: "e3", date: "2026-06-14", time: "6:00 PM", pillar: "sourdough",
      location: "Our Home", address: "Brookshire, TX", status: "confirmed",
      seats: 6, guestIds: ["g1","g8","g9","g13","g7","g3"],
      paid: 6, revenue: 6 * SEAT,
      prep: [
        { item: "Mini sourdough loaves", qty: 6, done: true },
        { item: "Dried starter packets", qty: 6, done: true },
        { item: "Flavored butter", qty: 6, done: false },
        { item: "Seasonal jam jars", qty: 6, done: false },
        { item: "Recipe cards printed", qty: 6, done: false },
      ],
    },
    {
      id: "e4", date: "2026-06-21", time: "5:30 PM", pillar: "pastry",
      location: "Guest's Home", address: "Katy, TX · Elena Sorensen", status: "confirmed",
      seats: 6, guestIds: ["g4","g11","g2","g6","g12"],
      paid: 5, revenue: 5 * SEAT,
      prep: [
        { item: "Mini tart shells", qty: 18, done: false },
        { item: "Mini cake bases", qty: 12, done: false },
        { item: "Buttercream batches", qty: 2, done: false },
        { item: "Travel kit packed", qty: 1, done: false },
        { item: "Recipe cards printed", qty: 6, done: false },
      ],
    },
    {
      id: "e5", date: "2026-06-28", time: "6:00 PM", pillar: "sourdough",
      location: "Our Home", address: "Brookshire, TX", status: "confirmed",
      seats: 6, guestIds: ["g8","g9","g1","g13"],
      paid: 4, revenue: 4 * SEAT,
      prep: [
        { item: "Mini sourdough loaves", qty: 4, done: false },
        { item: "Dried starter packets", qty: 4, done: false },
        { item: "Flavored butter", qty: 4, done: false },
        { item: "Seasonal jam jars", qty: 4, done: false },
        { item: "Recipe cards printed", qty: 4, done: false },
      ],
    },
    {
      id: "e6", date: "2026-07-12", time: "6:00 PM", pillar: "pastry",
      location: "Our Home", address: "Brookshire, TX", status: "confirmed",
      seats: 6, guestIds: ["g4","g5"],
      paid: 2, revenue: 2 * SEAT,
      prep: [
        { item: "Mini tart shells", qty: 18, done: false },
        { item: "Mini cake bases", qty: 12, done: false },
        { item: "Buttercream batches", qty: 2, done: false },
        { item: "Recipe cards printed", qty: 6, done: false },
      ],
    },
  ];

  // Pending booking requests awaiting approve / decline
  const REQUESTS = [
    {
      id: "r1", name: "Cole Berenson", email: "cole.b@protonmail.com", phone: "(713) 555-0133",
      guestId: "g7", party: 2, pillar: "sourdough", preferredDate: "2026-06-14",
      location: "Our Home", submitted: "2026-06-10", occasion: "Anniversary",
      message: "It's our first anniversary and we'd love to do something hands-on together. Is the 14th still open for two?",
    },
    {
      id: "r2", name: "Reuben Castile", email: "reuben.c@gmail.com", phone: "(281) 555-0102",
      guestId: "g12", party: 4, pillar: "pastry", preferredDate: "2026-06-21",
      location: "Guest's Home", submitted: "2026-06-09", occasion: "Friends night",
      message: "Group of four, all beginners. We're in Katy — would love the pastry evening if Brittany has room.",
    },
    {
      id: "r3", name: "Devin Park", email: "devin.park@gmail.com", phone: "(713) 555-0121",
      guestId: "g10", party: 3, pillar: "sourdough", preferredDate: "2026-06-28",
      location: "Our Home", submitted: "2026-06-09", occasion: "Birthday",
      message: "Booking for my mom's birthday — she's been wanting to learn sourdough forever.",
    },
    {
      id: "r4", name: "Theo Vanderwall", email: "theo.v@gmail.com", phone: "(832) 555-0173",
      guestId: "g14", party: 2, pillar: "pastry", preferredDate: "2026-07-12",
      location: "Our Home", submitted: "2026-06-08", occasion: "Date night",
      message: "Saw you on Instagram. Any chance of two seats for the July pastry night?",
    },
  ];

  // Inquiry messages (lighter than formal requests)
  const MESSAGES = [
    {
      id: "m1", name: "Hannah Whitfield", guestId: "g6", time: "2h ago", unread: true,
      preview: "Do you ever do larger private buyouts for a bridal party of 8?",
      body: "Hi Jaime & Brittany! I'm planning a bridal shower and wondered if you ever take the full evening private for a group of 8 — I know it's above your usual six. Happy to travel to you. Thank you!",
    },
    {
      id: "m2", name: "Saanvi Rao", guestId: "g8", time: "Yesterday", unread: true,
      preview: "Bringing two friends on the 14th — can they pay separately?",
      body: "Looking forward to the 14th! Two friends want to join and would rather each pay their own seat. Is that something you can set up? Thanks so much.",
    },
    {
      id: "m3", name: "Margaret Fenn", guestId: "g9", time: "2 days ago", unread: false,
      preview: "Thank you again — the herb butter was unreal.",
      body: "Just had to say thank you for last week. The herb butter was unreal and I've already rehydrated my starter. See you on the 14th!",
    },
    {
      id: "m4", name: "Ana Belmonte", guestId: "g13", time: "3 days ago", unread: false,
      preview: "Sharing the photos from the May evening — feel free to use any.",
      body: "Here's the gallery from the May 24th evening. Use anything you'd like on the site or Instagram — tag me if you do. They turned out beautifully.",
    },
  ];

  const REVIEWS = [
    { id: "rv1", name: "Elena Sorensen", guestId: "g4", rating: 5, pillar: "pastry", date: "Jun 8, 2026",
      text: "Brittany makes you feel like you've baked your whole life. I left with three tarts, two cakes, and a new hobby. This is the fourth evening I've booked and it won't be the last.", featured: true },
    { id: "rv2", name: "Maren Holloway", guestId: "g1", rating: 5, pillar: "sourdough", date: "May 25, 2026",
      text: "Small on purpose, and you feel it. We shaped loaves, churned butter, and grazed the most beautiful spread while the bread baked. Jaime is the warmest host imaginable.", featured: true },
    { id: "rv3", name: "Tomás Iglesias", guestId: "g5", rating: 5, pillar: "pastry", date: "Jun 8, 2026",
      text: "They handled my nut allergy without me even having to ask twice. Thoughtful, calm, and genuinely fun. The mini cakes were a highlight.", featured: false },
    { id: "rv4", name: "Saanvi Rao", guestId: "g8", rating: 5, pillar: "sourdough", date: "May 26, 2026",
      text: "I keep bringing friends because every evening feels different and every single one leaves happy. The dried starter packet is such a lovely touch.", featured: false },
    { id: "rv5", name: "Cole Berenson", guestId: "g7", rating: 4, pillar: "sourdough", date: "Jun 2, 2026",
      text: "A genuinely special night out that doesn't feel like a class. Only wish it ran a little longer — we didn't want to leave.", featured: false },
  ];

  // Monthly revenue (for the chart) — through current month
  const REVENUE_MONTHLY = [
    { month: "Jan", evenings: 3, revenue: 2465 },
    { month: "Feb", evenings: 4, revenue: 3480 },
    { month: "Mar", evenings: 5, revenue: 4205 },
    { month: "Apr", evenings: 5, revenue: 4350 },
    { month: "May", evenings: 6, revenue: 5075 },
    { month: "Jun", evenings: 4, revenue: 3045, partial: true },
  ];

  window.PantryData = {
    HOSTS, PILLARS, SEAT, GUESTS, gmap, EVENINGS, REQUESTS, MESSAGES, REVIEWS, REVENUE_MONTHLY,
    TODAY: new Date(2026, 5, 11, 18, 0),
  };
})();
