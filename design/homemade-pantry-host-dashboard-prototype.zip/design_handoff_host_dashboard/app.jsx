/* ════════════════════ APP SHELL ════════════════════ */

const DashCtx = React.createContext();
window.DashCtx = DashCtx;

const NAV = [
  { group: 'Kitchen', items: [
    { key: 'overview', label: 'Overview', icon: 'home' },
    { key: 'bookings', label: 'Bookings & Requests', icon: 'inbox', badge: 'requests' },
    { key: 'calendar', label: 'Calendar', icon: 'calendar' },
    { key: 'guests', label: 'Guests', icon: 'users' },
  ]},
  { group: 'Business', items: [
    { key: 'revenue', label: 'Revenue', icon: 'dollar' },
    { key: 'prep', label: 'Prep & Take-home', icon: 'clipboard' },
    { key: 'menus', label: 'Menus', icon: 'book' },
  ]},
  { group: 'Guests & Word of Mouth', items: [
    { key: 'messages', label: 'Messages', icon: 'mail', badge: 'unread' },
    { key: 'reviews', label: 'Reviews', icon: 'star' },
  ]},
];

const TITLES = {
  overview:  { eyebrow: 'The Homemade Pantry', title: 'Host Dashboard' },
  bookings:  { eyebrow: 'Kitchen', title: 'Bookings & Requests' },
  calendar:  { eyebrow: 'Kitchen', title: 'Calendar' },
  guests:    { eyebrow: 'Kitchen', title: 'Guests' },
  revenue:   { eyebrow: 'Business', title: 'Revenue' },
  prep:      { eyebrow: 'Business', title: 'Prep & Take-home' },
  menus:     { eyebrow: 'Business', title: 'Menus' },
  messages:  { eyebrow: 'Guests', title: 'Messages' },
  reviews:   { eyebrow: 'Guests', title: 'Reviews' },
  settings:  { eyebrow: 'Account', title: 'Settings' },
};

const ACCENTS = {
  teal: { '--accent': '#2C6E6A', '--accent-soft': '#E4F4F3', '--accent-deep': '#1E4B48' },
  clay: { '--accent': '#B87050', '--accent-soft': '#F4E6DA', '--accent-deep': '#7a4730' },
  sage: { '--accent': '#5f7e63', '--accent-soft': '#e8f0e9', '--accent-deep': '#3f5743' },
};

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "sidebar": "dark",
  "accent": "teal",
  "density": "regular",
  "serifHeadings": true
}/*EDITMODE-END*/;

function Sidebar({ setNav, activeKey, counts, tweak }) {
  const PD = window.PantryData;
  return (
    <aside className="side">
      <div className="side-head">
        <div className="side-logo"><WheatMark size={24} color={tweak.sidebar === 'light' ? 'var(--accent)' : '#FDF9F4'} /></div>
        <div className="side-wordmark">
          <div className="wm-1">The Homemade Pantry</div>
          <div className="wm-2">Made slowly · Shared warmly</div>
        </div>
      </div>
      <nav className="side-nav">
        {NAV.map(grp => (
          <div key={grp.group}>
            <div className="side-group-label">{grp.group}</div>
            {grp.items.map(it => (
              <button key={it.key} className={`side-item ${activeKey === it.key ? 'active' : ''}`}
                      onClick={() => setNav(it.key)}>
                <span className="ico-c"><Icon name={it.icon} size={18} /></span>
                <span>{it.label}</span>
                {it.badge && counts[it.badge] > 0 && <span className="side-badge">{counts[it.badge]}</span>}
              </button>
            ))}
          </div>
        ))}
      </nav>
      <div className="side-foot">
        <div className="side-avatars">
          <div className="side-av av-teal">J</div>
          <div className="side-av av-clay">B</div>
        </div>
        <div className="side-foot-text">
          <div className="sf-1">Jaime &amp; Brittany</div>
          <div className="sf-2">Brookshire, TX</div>
        </div>
        <button className="side-foot-gear" onClick={() => setNav('settings')}><Icon name="settings" size={17} /></button>
      </div>
    </aside>
  );
}

function App() {
  const PD = window.PantryData;
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [nav, setNavState] = React.useState('overview');
  const [query, setQuery] = React.useState('');
  const [evenings, setEvenings] = React.useState(() => JSON.parse(JSON.stringify(PD.EVENINGS)));
  const [requests, setRequests] = React.useState(() => JSON.parse(JSON.stringify(PD.REQUESTS)));
  const [messages, setMessages] = React.useState(() => JSON.parse(JSON.stringify(PD.MESSAGES)));
  const [openEveningId, setOpenEveningId] = React.useState(null);
  const [toast, setToast] = React.useState(null);
  const toastTimer = React.useRef();

  const setNav = (k) => { setNavState(k); setQuery(''); document.querySelector('.content')?.scrollTo(0, 0); };

  const showToast = (msg) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2600);
  };

  const togglePrep = (evId, idx) => {
    setEvenings(evs => evs.map(e => e.id !== evId ? e : { ...e, prep: e.prep.map((p, i) => i === idx ? { ...p, done: !p.done } : p) }));
  };

  const approveRequest = (reqId) => {
    const req = requests.find(r => r.id === reqId);
    if (!req) return;
    setRequests(rs => rs.filter(r => r.id !== reqId));
    // add the guest to the matching evening, or note it
    setEvenings(evs => evs.map(e => {
      if (e.date === req.preferredDate && e.pillar === req.pillar && !e.guestIds.includes(req.guestId)) {
        const addSeats = Math.min(req.party, e.seats - e.paid);
        return { ...e, guestIds: e.guestIds.includes(req.guestId) ? e.guestIds : [...e.guestIds, req.guestId], paid: e.paid + addSeats, revenue: e.revenue + addSeats * PD.SEAT };
      }
      return e;
    }));
    showToast(`Approved — ${req.name} added to ${fmtDate(req.preferredDate)}`);
  };

  const declineRequest = (reqId) => {
    const req = requests.find(r => r.id === reqId);
    setRequests(rs => rs.filter(r => r.id !== reqId));
    if (req) showToast(`Declined ${req.name}’s request`);
  };

  const markMessageRead = (id) => setMessages(ms => ms.map(m => m.id === id ? { ...m, unread: false } : m));

  const ctx = {
    nav, setNav, query, setQuery,
    evenings, requests, messages,
    openEveningId,
    openEvening: (id) => setOpenEveningId(id),
    closeDrawer: () => setOpenEveningId(null),
    togglePrep, approveRequest, declineRequest, markMessageRead, showToast,
  };

  const counts = { requests: requests.length, unread: messages.filter(m => m.unread).length };

  const rootStyle = { ...ACCENTS[t.accent] };
  const view = {
    overview: OverviewView, bookings: BookingsView, calendar: CalendarView, guests: GuestsView,
    revenue: RevenueView, prep: PrepView, menus: MenusView, messages: MessagesView,
    reviews: ReviewsView, settings: SettingsView,
  }[nav];
  const ViewComp = view || OverviewView;
  const title = TITLES[nav] || TITLES.overview;

  const showSearch = ['bookings', 'guests'].includes(nav);

  return (
    <DashCtx.Provider value={ctx}>
      <div className="app" data-side={t.sidebar} data-density={t.density} style={rootStyle}
           data-screen-label={`Dashboard · ${title.title}`}>
        <Sidebar setNav={setNav} activeKey={nav} counts={counts} tweak={t} />
        <div className="main">
          <header className="topbar">
            <div className="topbar-titles">
              <div className="topbar-eyebrow">{title.eyebrow}</div>
              <div className="topbar-title" style={{ fontFamily: t.serifHeadings ? 'var(--font-serif)' : 'var(--font-ui)', fontWeight: t.serifHeadings ? 500 : 600 }}>{title.title}</div>
            </div>
            <div className="topbar-spacer"></div>
            {showSearch && (
              <div className="searchbox">
                <Icon name="search" size={16} />
                <input placeholder={nav === 'guests' ? 'Search guests…' : 'Search bookings…'} value={query} onChange={e => setQuery(e.target.value)} />
              </div>
            )}
            <button className="top-icon-btn" onClick={() => setNav('messages')}>
              <Icon name="bell" size={18} />
              {counts.unread > 0 && <span className="dot"></span>}
            </button>
            <button className="top-cta" onClick={() => showToast('Opening new evening form')}>
              <Icon name="plus" size={15} /> New evening
            </button>
          </header>
          <div className="content">
            <ViewComp />
          </div>
        </div>

        {openEveningId && <EveningDrawer />}

        <div className={`toast ${toast ? 'show' : ''}`}>
          {toast && <React.Fragment><Icon name="check" size={16} />{toast}</React.Fragment>}
        </div>

        <TweaksPanel title="Tweaks">
          <TweakSection label="Sidebar" />
          <TweakRadio label="Theme" value={t.sidebar} options={['dark', 'light']} onChange={v => setTweak('sidebar', v)} />
          <TweakSection label="Accent" />
          <TweakColor label="Color" value={ACCENTS[t.accent]['--accent']}
                      options={['#2C6E6A', '#B87050', '#5f7e63']}
                      onChange={v => {
                        const key = Object.keys(ACCENTS).find(k => ACCENTS[k]['--accent'].toLowerCase() === v.toLowerCase()) || 'teal';
                        setTweak('accent', key);
                      }} />
          <TweakSection label="Layout" />
          <TweakRadio label="Density" value={t.density} options={['compact', 'regular', 'comfy']} onChange={v => setTweak('density', v)} />
          <TweakToggle label="Serif headings" value={t.serifHeadings} onChange={v => setTweak('serifHeadings', v)} />
        </TweaksPanel>
      </div>
    </DashCtx.Provider>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
